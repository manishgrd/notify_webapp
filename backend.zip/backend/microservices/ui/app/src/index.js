import React from 'react';
import ReactDOM from 'react-dom';

import HasuraExampleApp from './hasuraExamples/HasuraExampleApp';

//Replace HasuraExampleApp with your own component
ReactDOM.render(
  <HasuraExampleApp />,
  document.getElementById('root')
);
