# microservices 

Everything regarding the micro-services you add to the project is kept here. Each microservice is a directory containing a `k8s.yaml` file which holds the Kubernetes objects required for it and a `src` directory, if continuous integration is configured.

`k8s.yaml` can also be templated.
